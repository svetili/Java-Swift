
public class CreateArray {

	public static void main(String[] args) {
		int[] intArr = { 5, 9, 11, 3, 6, 4, 7 };
		for (int i = 0; i < intArr.length; i++) {
			System.out.printf("%d ", intArr[i]);
		}
	}

}
